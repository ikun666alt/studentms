package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Course;
import util.StrUtil;


public class CourseDao extends ConnDao {
	 public List<Course> getCourseList(Course c){
	  		List<Course> list=new ArrayList<>();
	  		StringBuffer sql=new StringBuffer("select * from course");
	  		
	  		if(c.getTid()!=0) {
	  			sql.append(" and tid="+c.getTid());
	  		}
	  		if(!StrUtil.isEmpty(c.getName())) {
	  			sql.append(" and name like '%"+c.getName()+"%'");
	  		}
	  		try {
	  			PreparedStatement pst=conn.prepareStatement(sql.toString().replaceFirst("and", "where"));
	  			ResultSet rs=pst.executeQuery();
	  			while(rs.next()) {
	  				Course cou=new Course();
	  				cou.setId(rs.getInt("id"));
	  				cou.setName(rs.getString(2));
	  				cou.setTid(rs.getInt("tid"));
	  				cou.setMaxStuNum(rs.getInt("maxStuNum"));
	  				cou.setInfo(rs.getString("info"));
	  				cou.setSelectedNum(rs.getInt("selectednum"));
	  				list.add(cou);				
	  			}
	  		  
	  		} catch (SQLException e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  		return list;
	  	}
	 
	 //�жϸÿγ��ܷ�ѡ������ѡ���������ڵ������ѡ��������������ѡ��
	 public boolean selectEnable(int id) {
		 String sql="select * from course where id=?";
		 try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				int maxNum=rs.getInt("maxStuNum");
				int selectednum=rs.getInt("selectednum");
				if(selectednum>=maxNum)
					return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return true;
	 }
	 
	 //������ѡ��ÿγ̵��������γ���selectednum����ֻ��ͨ��ѡ�λ�����ѡ�Ķ������ı���ֵ��
	 public boolean updateNum(int id,int num) {
		 String sql="update course set selectednum=selectednum + ? where id=?";
		 
	  		try {
	  			PreparedStatement pst=conn.prepareStatement(sql);
	  			pst.setInt(1,num);
	  			pst.setInt(2,id);
	  			if(pst.executeUpdate()>0) {
	  				return true;
	  			}
	  		} catch (SQLException e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
		 
		 return false;
	 }
}
