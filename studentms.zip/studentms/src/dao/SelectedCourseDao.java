package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import model.SelectedCourse;

public class SelectedCourseDao extends ConnDao{
	
	public boolean add(SelectedCourse sc) {
		boolean flag=false;
		String sql="insert into selectedcourse(cid,sid) values(?,?)";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, sc.getCid());
			pst.setInt(2, sc.getSid());
			if(pst.executeUpdate()>0) {
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
    
	public boolean delete(int id) {
		boolean flag=false;
		String sql="delete from selectedcourse where id=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, id);
			if(pst.executeUpdate()>0) {
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean update(SelectedCourse sc) {
		boolean flag=false;
		String sql="update selectedcourse set cid=?,sid=? where id=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, sc.getCid());
			pst.setInt(2, sc.getSid());
			pst.setInt(3, sc.getId());
			if(pst.executeUpdate()>0) {
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public List<SelectedCourse> getSelectedCourseList(SelectedCourse sc){
		List<SelectedCourse> list=new ArrayList<>();
		StringBuffer sql=new StringBuffer("select * from selectedcourse");
		if(sc.getCid()!=0) {
			sql.append(" and cid="+sc.getCid());
		}
		if(sc.getSid()!=0) {
			sql.append(" and sid="+sc.getSid());
		}
		try {
			PreparedStatement pst=conn.prepareStatement(sql.toString().replaceFirst("and", "where"));
			
			ResultSet rs=pst.executeQuery() ;
			while(rs.next()) {
				SelectedCourse seleCou=new SelectedCourse();
				seleCou.setId(rs.getInt("id"));
				seleCou.setCid(rs.getInt("cid"));
				seleCou.setSid(rs.getInt("sid"));
				list.add(seleCou);				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	//�жϸ�ѧ���Ƿ���ѡ�������ſΣ�����ѡ�񷵻�true������������ͨ���÷���ֵ���Խ�ֹ��ѧ������ѡ��ͬһ�ſγ�
	public boolean isSelected(SelectedCourse sc) {
		String sql="select * from selectedcourse where sid=? and cid=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, sc.getSid());
			pst.setInt(2, sc.getCid());
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
