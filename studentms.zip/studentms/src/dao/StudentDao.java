package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Student;
import util.StrUtil;


public class StudentDao extends ConnDao {
      public boolean add(Student student) {
    	  String sql="insert into student values(null,?,?,?,?)";
    	  try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, student.getName());
			pst.setInt(2, student.getClassId());
			pst.setString(3, student.getPassword());
			pst.setString(4, student.getSex());
			if(pst.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
    	  return false;
      }
      
     
      public boolean delete(int id) {
  		String sql="delete from student where id=?";
  		try {
  			PreparedStatement pst=conn.prepareStatement(sql);
  			pst.setInt(1, id);
  			if(pst.executeUpdate()>0) {
  				return true;
  			}
  		} catch (SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
  		
  		return false;
  	}
      
      public boolean update(Student stu) {
  		String sql="update student set name=? , classid=?,password=?,sex=? where id=?";
  		try {
  			PreparedStatement pst=conn.prepareStatement(sql);
  			pst.setString(1,stu.getName());
  			pst.setInt(2, stu.getClassId());
  			pst.setString(3, stu.getPassword());
  			pst.setString(4,stu.getSex());
  			pst.setInt(5, stu.getId());
  			if(pst.executeUpdate()>0) {
  				return true;
  			}
  		} catch (SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
  		return false;
  	}
      
      public List<Student> getStudentList(Student stud){
    		List<Student> list=new ArrayList<>();
    		StringBuffer sql=new StringBuffer("select * from student");
    		if(!StrUtil.isEmpty(stud.getName())) {
    			sql.append(" and name like '%"+stud.getName()+"%'");
    		}
    		if(stud.getClassId()!=0) {
    			sql.append(" and classid="+stud.getClassId());
    		}
    		try {
    			PreparedStatement pst=conn.prepareStatement(sql.toString().replaceFirst("and", "where"));
    			ResultSet rs=pst.executeQuery();
    			while(rs.next()) {
    				Student stu=new Student();
    				stu.setId(rs.getInt("id"));
    				stu.setName(rs.getString(2));
    				stu.setPassword(rs.getString("password"));
    				stu.setSex(rs.getString("sex"));
    				stu.setClassId(rs.getInt("classid"));
    				list.add(stu);				
    			}
    		  
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		return list;
    	}
        
      
      
      public Student login(Student student) {
   	   Student stu=null;
   	   
   	   return stu;
}
}