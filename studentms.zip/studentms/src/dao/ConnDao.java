package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnDao {
    public Connection conn=getConn();
    
    private Connection getConn() {
      	 String url="jdbc:mysql://localhost:3306/studentms";
      	 String name="root";
      	 String password="123456";
   		 Connection  con=null;
   	    //Class.forName("com.mysql.cj.jdbc.Driver");����8.0����������
   		//String url="jdbc:mysql://localhost:3306/studentms?user=root&password=123456";
   		try {
   			con=DriverManager.getConnection(url,name,password);
   		} catch (SQLException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}	
   		return con;
   		}
    
    public void closeDao() {
      if(conn!=null) {
    	try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
      }
    } 
}
	
	