package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.SClass;
import util.StrUtil;


public class ClassDao extends ConnDao {
	public boolean add(SClass sc) {
		String sql="insert into sclass(name,info) values(?,?)";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, sc.getName());
			pst.setString(2,sc.getInfo());
			if(pst.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;		
	}
	
	
	
	public boolean delete(int id) {
		String sql="delete from sclass where id=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, id);
			if(pst.executeUpdate()>0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean update(SClass sc) {
		String sql="update sclass set name=? , info=? where id=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,sc.getName());
			pst.setString(2, sc.getInfo());
			pst.setInt(3, sc.getId());
			if(pst.executeUpdate()>0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public List<SClass> getClassList(SClass sc){
		List<SClass> list=new ArrayList<>();
		String sql="select * from sclass";
		if(!StrUtil.isEmpty(sc.getName())) {
			sql+=" where name like '%"+sc.getName()+"%'";
		}
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				SClass stuClass=new SClass();
				stuClass.setId(rs.getInt("id"));
				stuClass.setName(rs.getString("name"));
				stuClass.setInfo(rs.getString("info"));
				list.add(stuClass);	
				System.out.println(stuClass);
			}
		  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
