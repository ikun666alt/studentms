package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Admin;

public class AdminDao extends ConnDao {
	
   public Admin login(Admin admin) {
	   Admin ad=null;
	   String sql="select * from admin where name=? and password=?";
	   try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,admin.getName());
		pst.setString(2, admin.getPassword());
		ResultSet rst=pst.executeQuery();
		if(rst.next()) {
			ad=new Admin();
			ad.setId(rst.getInt("id"));
			ad.setName(rst.getString("name"));
			ad.setPassword(rst.getString("password"));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   return ad;
   }
   
   public String changePassword(Admin admin,String passwordNew) {
	   String sql="select * from admin where id=? and password=?";
	   PreparedStatement pst=null;
	   try {
		pst=conn.prepareStatement(sql);
		pst.setInt(1,admin.getId());
		pst.setString(2,admin.getPassword());
		ResultSet result=pst.executeQuery();
		if(!result.next()) {
			String reString="ԭʼ�������!";
			return reString;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	   String reString="�����޸�ʧ��";
	   sql="update admin set password=? where id=?";
	   try {
		pst=conn.prepareStatement(sql);
		pst.setString(1, passwordNew);
		pst.setInt(2, admin.getId());
		int n=pst.executeUpdate();
		if(n>0) {
			reString="�����޸ĳɹ�!";
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return reString;
   }
}
