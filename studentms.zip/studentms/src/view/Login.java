package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.AdminDao;
import model.Admin;
import util.StrUtil;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField tf;
	private JPasswordField pf;
	private JComboBox cb;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("\u767B\u5F55\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 508);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		//this.setLocationRelativeTo(null);//�������
		this.setLocation(500, 350);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u9009\u8BFE\u7CFB\u7EDF");
		lblNewLabel.setBounds(238, 73, 331, 64);
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/images/\u5B66\u751F2.png")));
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 26));
		
		JLabel lblNewLabel_1 = new JLabel("\u7528\u6237\u59D3\u540D\uFF1A");
		lblNewLabel_1.setBounds(237, 189, 76, 15);
		
		tf = new JTextField();
		tf.setBounds(331, 186, 123, 21);
		tf.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\u5BC6     \u7801\uFF1A");
		lblNewLabel_2.setBounds(237, 238, 82, 15);
		
		pf = new JPasswordField();
		pf.setBounds(331, 234, 125, 23);
		
		JLabel lblNewLabel_3 = new JLabel("\u7528\u6237\u7C7B\u578B\uFF1A");
		lblNewLabel_3.setBounds(237, 287, 76, 15);
		
		cb = new JComboBox();
		cb.setBounds(331, 284, 123, 21);
		cb.setModel(new DefaultComboBoxModel(new String[] {"\u7BA1\u7406\u5458", "\u6559\u5E08", "\u5B66\u751F"}));
		
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login(e);
			}});
		btnNewButton.setBounds(172, 360, 76, 23);
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.setBounds(341, 360, 76, 23);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tf.setText("");
				pf.setText("");
				cb.setSelectedIndex(0);
			}
		});
		
		JButton btnNewButton_2 = new JButton("\u9000\u51FA");
		btnNewButton_2.setBounds(502, 360, 67, 23);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel_2);
		contentPane.add(pf);
		contentPane.add(lblNewLabel_1);
		contentPane.add(tf);
		contentPane.add(lblNewLabel_3);
		contentPane.add(cb);
		contentPane.add(btnNewButton);
		contentPane.add(btnNewButton_1);
		contentPane.add(btnNewButton_2);
		contentPane.add(lblNewLabel);
	}

	protected void login(ActionEvent e) {
		String name=tf.getText();
		String password=new String(pf.getPassword());
		String iden=(String) cb.getSelectedItem();
		
		if(StrUtil.isEmpty(name)) {
			JOptionPane.showMessageDialog(this, "�û�������Ϊ��");
			return;
		}
		if(StrUtil.isEmpty(password)) {
			JOptionPane.showMessageDialog(this, "���벻��Ϊ��");
			return;
		}
		if("����Ա".equals(cb.getSelectedItem())) {
			Admin ad=new Admin();
			ad.setName(name);
			ad.setPassword(password);
			AdminDao add=new AdminDao();
			Admin admin=add.login(ad);
			add.closeDao();
			if(admin!=null) {
				JOptionPane.showMessageDialog(this, "��ӭ����Ա"+admin.getName()+"��¼");
				MainJFrm mf=new MainJFrm(admin,iden);
				mf.setVisible(true);
				this.dispose();
			}else {
				JOptionPane.showMessageDialog(this, "�û��������������");
			    return;
			}
		}
		//else if("ѧ��".equals(cb.getSelectedItem()))
		//�˴�����չѧ������ʦ
		
	}
}
