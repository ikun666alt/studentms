package view;

import java.awt.EventQueue;
import java.util.List;
import java.util.Vector;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.CourseDao;
import dao.SelectedCourseDao;
import dao.StudentDao;
import model.Course;
import model.SelectedCourse;
import model.Student;
import util.StrUtil;

import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ManageSelectedCourseFrm extends JInternalFrame {
	private JTable table;
	private JComboBox cb2;
	private JComboBox cb1;
	private JButton btn1;
	private JComboBox cb3;
	private JComboBox cb4;

	
	public ManageSelectedCourseFrm() {
		setTitle("\u9009\u8BFE");
		setBounds(100, 100, 592, 487);
		this.setClosable(true);
		this.setIconifiable(true);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\uFF1A");
		
		cb1 = new JComboBox();
		
		JLabel lblNewLabel_1 = new JLabel("\u8BFE\u7A0B\uFF1A");
		
		cb2 = new JComboBox();
		
		btn1 = new JButton("\u786E\u8BA4\u9009\u8BFE");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectCourse(e);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u4FEE\u6539\u9009\u8BFE\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(75)
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(cb1, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
							.addGap(66)
							.addComponent(lblNewLabel_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(cb2, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE)
							.addGap(33)
							.addComponent(btn1))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(46)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 458, GroupLayout.PREFERRED_SIZE)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 462, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(68, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(cb1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1)
						.addComponent(cb2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn1))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 208, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(31, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_2 = new JLabel("\u5B66\u751F\uFF1A");
		
		cb3 = new JComboBox();
		cb3.setEnabled(false);
		
		JLabel lblNewLabel_3 = new JLabel("\u8BFE\u7A0B\uFF1A");
		
		cb4 = new JComboBox();
		
		JButton btn2 = new JButton("\u786E\u8BA4\u4FEE\u6539");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifySelectedCourse(e);
			}
		});
		
		JButton btn3 = new JButton("\u9000\u9009\u8BFE\u7A0B");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(45)
					.addComponent(lblNewLabel_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(btn2)
							.addGap(81)
							.addComponent(btn3))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(cb3, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
							.addGap(72)
							.addComponent(lblNewLabel_3)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(cb4, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(56, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(cb4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cb3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2))
					.addPreferredGap(ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btn2)
						.addComponent(btn3))
					.addGap(22))
		);
		panel.setLayout(gl_panel);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selectRow(e);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u9009\u8BFE\u7F16\u53F7", "\u5B66\u751F\u59D3\u540D", "\u8BFE\u7A0B\u540D\u79F0"
			}
		));
		scrollPane.setViewportView(table);
		getContentPane().setLayout(groupLayout);
		initStudent();
		initCourse();
		initTable(new SelectedCourse());
        
	}
	
	//ѡ�б�����У�ʹ��������·��������б�����
	protected void selectRow(MouseEvent e) {
		int row =table.getSelectedRow();		
		String sname=table.getValueAt(row, 1).toString();
		String cname=table.getValueAt(row, 2).toString();
		
		for(int i=0;i<cb3.getItemCount();i++) {
			Student st=(Student) cb3.getItemAt(i);
			if(sname.equals(st.getName())) {
				cb3.setSelectedIndex(i);
				break;
			}
		}
		for(int i=0;i<cb4.getItemCount();i++) {
			Course co=(Course) cb4.getItemAt(i);
			if(cname.equals(co.getName())) {
				cb4.setSelectedIndex(i);
				break;
			}
		}
		
	}

	//�޸�ѡ����Ϣ
	protected void modifySelectedCourse(ActionEvent e) {
		int row=table.getSelectedRow();
		if(row==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ���");
			return;
		}
		
		int id=Integer.parseInt(table.getValueAt(row, 0).toString());
		String sname=table.getValueAt(row, 1).toString();
		String cname=table.getValueAt(row, 2).toString();//�������Ǳ��д洢��ԭ������
		
		Student sc=(Student) cb3.getSelectedItem();
	    Course co=(Course) cb4.getSelectedItem();//�����޸��Ժ�����ݣ�Ŀǰ��δ�޸ģ�
	    
	    if(sname.equals(sc.getName()) && cname.equals(co.getName())) {
	    	//���ԭ�����ݺ�Ҫ�޸ĵ�������һ����
	    	JOptionPane.showMessageDialog(this,"��ԭʼ������ͬ����δ�޸�����");
			return;
	    }
	    
	    CourseDao cd=new CourseDao();
		if(!cd.selectEnable(co.getId())) {
			JOptionPane.showMessageDialog(this,"�ÿγ���ѡ���������ٽ���ѡ��");
			return;
		}
		
		SelectedCourse seco=new SelectedCourse();
		seco.setId(id);
		seco.setCid(co.getId());
		seco.setSid(sc.getId());
		
		SelectedCourseDao sedao=new SelectedCourseDao();		
		if(sedao.isSelected(seco)) {
			JOptionPane.showMessageDialog(this,"�ÿγ�����ѡ�񣬲����ظ�ѡ��");
			return ;
		}
		
		if(sedao.update(seco)) {
			if(cd.updateNum(seco.getCid(), 1)) {//�޸ĺ�Ŀγ���ѡ����+1
				if(cd.updateNum(cnameChangeCid(cname),-1)) {//ԭ���Ŀγ���ѡ����-1
					JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
				}else
					JOptionPane.showMessageDialog(this,"�޸�ʧ��");
			}			
		}
		sedao.closeDao();
		cd.closeDao();
		initTable(new SelectedCourse());
		//setControl() ;//��չ����
		
	}

	//ѡ�Σ�����ѧ�������Ϳγ����ƣ�
	protected void selectCourse(ActionEvent e) {
		Student st=(Student) cb1.getSelectedItem();
		Course co=(Course) cb2.getSelectedItem();
		
		SelectedCourse sc=new SelectedCourse();
		sc.setSid(st.getId());
		sc.setCid(co.getId());
		
		CourseDao cd=new CourseDao();
		if(!cd.selectEnable(co.getId())) {
			JOptionPane.showMessageDialog(this,"�ÿγ���ѡ���������ٽ���ѡ��");
			return ;
		}
		
		SelectedCourseDao scd=new SelectedCourseDao();
		if(scd.isSelected(sc)) {
			JOptionPane.showMessageDialog(this,"�ÿγ�����ѡ�񣬲����ظ�ѡ��");
			return ;
		}
		
		if(scd.add(sc)) {//����ѡ����Ϣ���ӵ�ѡ�α���
			if(cd.updateNum(sc.getCid(), 1)){//���ÿγ�����ѡ����+1
				JOptionPane.showMessageDialog(this,"ѡ�γɹ�");
			}else
				JOptionPane.showMessageDialog(this,"��Ȼѡ�γɹ������γ̱�����ѡ��������ʧ��");
		}else
			JOptionPane.showMessageDialog(this,"ѡ��ʧ��");
		
		scd.closeDao();
		cd.closeDao();
		initTable(new SelectedCourse());
	}

	

	//��ʼ�������е�����ѧ�������б���
    public void initStudent() {
   	 StudentDao std=new StudentDao();
   	 List<Student> list=std.getStudentList(new Student());
   	 for(Student s:list) {
   		 cb1.addItem(s);
   		 cb3.addItem(s);
   	 } 
   	 std.closeDao();
   	 
 //�˴�����Ϊ��չ
//   if("ѧ��".equals(MainJFrm.iden)){//�����ѧ����¼����ֻ�ܿ����Լ���ѡ����Ϣ
//		Student user=(Student) MainJFrm.userObjcet;
//		for(int i=0;i<cb1.getItemCount();i++) {
//			Student stu=(Student) cb1.getItemAt(i);
//			if(user.getId()==stu.getId()) {
//				cb1.setSelectedIndex(i);
//				cb3.setSelectedIndex(i);
//				break;
//			}
//		}
//	  }
    
    }
    
  //��ʼ�������е������γ������б���
    public void initCourse() {
   	 CourseDao cd=new CourseDao();
   	 List<Course> list=cd.getCourseList(new Course());
   	 for(Course c:list) {
   		 cb2.addItem(c);
   		 cb4.addItem(c);
   	 } 
   	 cd.closeDao();
    }
	
	//��ʼ��������ʾ���е�ѡ����Ϣ
     protected void initTable(SelectedCourse sc) {
    	 SelectedCourseDao scd=new SelectedCourseDao();
    	 List<SelectedCourse> list=scd.getSelectedCourseList(sc);
    	 scd.closeDao();
    	 
    	 DefaultTableModel dtm=(DefaultTableModel) table.getModel();
    	 dtm.setRowCount(0);//��ԭ�����������
    	 
    	 for(SelectedCourse s:list) {
    		 Vector<Object> vec=new Vector<>();
    		 vec.add(s.getId());    		
    		 vec.add(sidChangeSname(s.getSid()));
    		 vec.add(cidChangeCname(s.getCid()));//ע�⣺���ӵ�˳��Ҫ�ͽ����еı����ֶ�˳��һ��
    		 dtm.addRow(vec);
    	 }
    
	}
     
     //���γ̱��ת���ɿγ����ƣ��˹���Ҳ���������ݿ���ͨ�����Ӳ�ѯ��ɣ�
     private String cidChangeCname(int cid) {
    	 CourseDao cd=new CourseDao();
    	List<Course> list= cd.getCourseList(new Course());
    	for(Course co:list) {
    		if(cid==co.getId()) {
    			return co.getName();
    		}
    	}
    	cd.closeDao();
    	return "";
     }
     
   //��ѧ�����ת����ѧ�����ƣ��˹���Ҳ���������ݿ���ͨ�����Ӳ�ѯ��ɣ�
     private String sidChangeSname(int sid) {
    	 StudentDao sd=new StudentDao();

    	List<Student> list= sd.getStudentList(new Student());
    	for(Student st:list) {
    		if(sid==st.getId()) {
    			return st.getName();
    		}
    	}
    	sd.closeDao();
    	return "";
     }
     
     
     //���γ�����ת���ɿγ̱��
     private int cnameChangeCid(String name) {
    	 CourseDao cd=new CourseDao();
     	List<Course> list= cd.getCourseList(new Course());
     	for(Course co:list) {
     		if(name.equals(co.getName())) {
     			return co.getId();
     		}
     	}
     	cd.closeDao();
     	return 0;
     }
     
     //����Ϊ��չ���ݣ������ѧ����¼����ѧ�������б��������������ã���ֻ�ܲ����Լ���ѡ�Ρ��޸�ѡ�κ��˿�
//     private void setControl() {
// 		if("ѧ��".equals(MainJFrm.iden)) {
// 			cb1.setEnabled(false);
// 			cb3.setEnabled(false);
// 		}
// 	}
     
}
