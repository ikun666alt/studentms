package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import dao.ClassDao;
import dao.StudentDao;
import model.SClass;
import model.Student;
import util.StrUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

public class AddStudentFrm extends JInternalFrame {
	private JTextField tf;
	private JPasswordField pf;
	private JRadioButton rb1;
	private JRadioButton rb2;
	private JComboBox cb;

	
	public AddStudentFrm() {
		setTitle("\u6DFB\u52A0\u5B66\u751F\u4FE1\u606F");
		setBounds(100, 100, 402, 354);
		this.setClosable(true); //���ùرհ�ť
		this.setIconifiable(true);//������С����ť
	
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		
		tf = new JTextField();
		tf.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6240\u5C5E\u73ED\u7EA7\uFF1A");
		
		cb = new JComboBox();
		
		JLabel lblNewLabel_2 = new JLabel("\u767B\u5F55\u5BC6\u7801\uFF1A");
		
		pf = new JPasswordField();
		
		JLabel lblNewLabel_3 = new JLabel("\u5B66\u751F\u6027\u522B\uFF1A");
		
		rb1 = new JRadioButton("\u7537");
		rb1.setSelected(true);
		
		rb2 = new JRadioButton("\u5973");
		ButtonGroup bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
	
		
		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addStudent(e);
			}
		});
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reset();
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(79)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel_2)
								.addGap(18)
								.addComponent(pf))
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel_1)
								.addGap(18)
								.addComponent(cb, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel)
								.addGap(18)
								.addComponent(tf, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnNewButton)
								.addComponent(lblNewLabel_3))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(rb1)
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(btnNewButton_1)
								.addComponent(rb2))))
					.addContainerGap(93, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(55)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(tf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(cb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2)
						.addComponent(pf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(rb1)
						.addComponent(rb2))
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addContainerGap(64, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
		initClass();//��ʼ�������б�������ʾ�İ༶��Ϣ

	}

	//��ʼ�������б�������ʾ�İ༶��Ϣ
	private void initClass() {
		ClassDao cd=new ClassDao();
		List<SClass> list=cd.getClassList(new SClass());
		for(SClass sc:list) {
			cb.addItem(sc);//�˴�����ֱ������sc���󣬵���ʾ���ǰ༶���ƣ���ΪSClass���е�toString�������ص���name
		}
		cd.closeDao();
	}

	
	protected void addStudent(ActionEvent e) {
		String name=tf.getText();
		String password=new String(pf.getPassword());
		String sex="��";
		if(rb2.isSelected()) {
			sex="Ů";
		}
		SClass sc=(SClass)(cb.getSelectedItem());
		
		if(StrUtil.isEmpty(name)) {
			JOptionPane.showMessageDialog(this, "ѧ��������Ϊ��");
			return;
		}
		if(StrUtil.isEmpty(password)) {
			JOptionPane.showMessageDialog(this, "���벻��Ϊ��");
			return;
		}
		
		Student st=new Student();
		st.setName(name);
		st.setPassword(password);
		st.setSex(sex);
		st.setClassId(sc.getId());
		
		StudentDao std=new StudentDao();
		if(std.add(st)) {
			JOptionPane.showMessageDialog(this, "ѧ�����ӳɹ�");
		}else
		{
			JOptionPane.showMessageDialog(this, "ѧ������ʧ��");
		}
		reset();
		std.closeDao();
	}

	
	protected void reset() {
		tf.setText("");
		pf.setText("");
		cb.setSelectedIndex(0);	
	}
}
