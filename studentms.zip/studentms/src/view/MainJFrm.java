package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Student;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.awt.event.InputEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Desktop;
import javax.swing.JDesktopPane;

public class MainJFrm extends JFrame {

	private JPanel contentPane;
	
	private JMenuItem menu21;
	private JDesktopPane desktopPane;
	public static Object userObject;//��֪����¼���ǹ���Ա����ʦ����ѧ����������Object����
	public static String iden;//��¼�����������б�����ѡ�е��ַ���

	
	public MainJFrm(Object userObject,String iden) {
		this.userObject=userObject;
		this.iden=iden;
		setTitle("\u5B66\u751F\u9009\u8BFE\u7CFB\u7EDF\u4E3B\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 824, 659);
		this.setLocationRelativeTo(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u7CFB\u7EDF\u7BA1\u7406");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		mntmNewMenuItem.setIcon(new ImageIcon(MainJFrm.class.getResource("/images/\u4FEE\u6539\u5BC6\u7801.png")));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\u9000\u51FA");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmNewMenuItem_1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1, InputEvent.ALT_DOWN_MASK));
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_1 = new JMenu("\u5B66\u751F\u7BA1\u7406");
		menuBar.add(mnNewMenu_1);
		
		menu21 = new JMenuItem("\u6DFB\u52A0\u5B66\u751F");
		menu21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddStudentFrm asf=new AddStudentFrm();
				asf.setVisible(true);
				desktopPane.add(asf);
			}
		});
		mnNewMenu_1.add(menu21);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("\u67E5\u8BE2\u5B66\u751F");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectStudentFrm ssf=new SelectStudentFrm();
				ssf.setVisible(true);
				desktopPane.add(ssf);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_4);
		
		JMenu mnNewMenu_5 = new JMenu("\u73ED\u7EA7\u7BA1\u7406");
		menuBar.add(mnNewMenu_5);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("\u6DFB\u52A0\u73ED\u7EA7");
		mnNewMenu_5.add(mntmNewMenuItem_5);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("\u67E5\u8BE2\u73ED\u7EA7");
		mnNewMenu_5.add(mntmNewMenuItem_6);
		
		JMenu mnNewMenu_2 = new JMenu("\u6559\u5E08\u7BA1\u7406");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("\u6DFB\u52A0\u6559\u5E08");
		mnNewMenu_2.add(mntmNewMenuItem_7);
		
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("\u67E5\u8BE2\u6559\u5E08");
		mnNewMenu_2.add(mntmNewMenuItem_8);
		
		JMenu mnNewMenu_3 = new JMenu("\u8BFE\u7A0B\u7BA1\u7406");
		menuBar.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("\u6DFB\u52A0\u8BFE\u7A0B");
		mnNewMenu_3.add(mntmNewMenuItem_9);
		
		JMenuItem mntmNewMenuItem_10 = new JMenuItem("\u67E5\u8BE2\u8BFE\u7A0B");
		mnNewMenu_3.add(mntmNewMenuItem_10);
		
		JMenu mnNewMenu_4 = new JMenu("\u9009\u8BFE\u7BA1\u7406");
		menuBar.add(mnNewMenu_4);
		
		JMenuItem mntmNewMenuItem_11 = new JMenuItem("\u9009\u8BFE");
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageSelectedCourseFrm mscf=new ManageSelectedCourseFrm();
				mscf.setVisible(true);
				desktopPane.add(mscf);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_11);
		
		JMenu mnNewMenu_6 = new JMenu("\u5E2E\u52A9");
		menuBar.add(mnNewMenu_6);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("\u8054\u7CFB\u6211\u4EEC");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				about(e);
			}
		});
		mnNewMenu_6.add(mntmNewMenuItem_2);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		desktopPane = new JDesktopPane();
		desktopPane.setBackground(new Color(230, 230, 250));
		contentPane.add(desktopPane, BorderLayout.CENTER);
		
		//setControl();
		
	}


	protected void about(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "��ϵ����");
		URI uri;
		try {
			uri=new URI("www.huel.edu.cn");
			Desktop.getDesktop().browse(uri);
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}	
	}
    
	//�˴�����չ
	//����ѧ������ʦ��Ȩ�ޣ�����ѧ���������ӿγ̣�����Խ����ӿγ̽�������Ϊ���ɼ��򲻿���
//	private void setControl() {
//		if("ѧ��".equals(iden)){
//			�˵��������.setEnabled(false);//����ʹ�ã���ɫ״̬
//			�˵��������.setVisible(false);//���ɼ�
//		}
//		if("��ʦ".equals(iden)) {
//			�˵��������.setEnabled(false);//����ʹ�ã���ɫ״̬
//			�˵��������.setVisible(false);//���ɼ�
//		}
//		
//	}
}
