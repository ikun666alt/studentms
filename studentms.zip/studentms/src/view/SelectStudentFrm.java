package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.ClassDao;
import dao.StudentDao;
import model.SClass;
import model.Student;
import util.StrUtil;


import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SelectStudentFrm extends JInternalFrame {
	private JTextField tf1;
	private JTable table;
	private JTextField tf2;
	private JPasswordField pf;
	private JComboBox cb2;
	private JComboBox cb1;
	private JRadioButton rb1;
	private JRadioButton rb2;
	private ButtonGroup bg;

	public SelectStudentFrm() {
		setTitle("\u67E5\u8BE2\u5B66\u751F\u4FE1\u606F");
		setBounds(100, 100, 614, 467);
		this.setClosable(true);
		this.setIconifiable(true);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		
		tf1 = new JTextField();
		tf1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6240\u5C5E\u73ED\u7EA7\uFF1A");
		
		cb1 = new JComboBox();
		
		JButton btn1 = new JButton("\u67E5\u8BE2");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    selectTable(e);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblNewLabel_2 = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		
		tf2 = new JTextField();
		tf2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\u6027\u522B\uFF1A");
		
		rb1 = new JRadioButton("\u7537");
		
		rb2 = new JRadioButton("\u5973");
		
		bg=new ButtonGroup(); //���õ�ѡ��ť��
		bg.add(rb1);
		bg.add(rb2);
		
		JLabel lblNewLabel_4 = new JLabel("\u6240\u5C5E\u73ED\u7EA7\uFF1A");
		
		JLabel lblNewLabel_5 = new JLabel("\u5BC6\u7801\uFF1A");
		
		pf = new JPasswordField();
		
		JButton btn2 = new JButton("\u786E\u8BA4\u4FEE\u6539");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifyAct(e);
			}
		});
		
		JButton btn3 = new JButton("\u786E\u8BA4\u5220\u9664");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteAct(e);
			}
		});
		
		cb2 = new JComboBox();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(54)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 455, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(tf1, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
							.addGap(48)
							.addComponent(lblNewLabel_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(cb1, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
							.addGap(50)
							.addComponent(btn1))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel_4)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(cb2, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel_2)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(tf2, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)))
							.addGap(48)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel_3)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rb1)
									.addGap(18)
									.addComponent(rb2))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel_5)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(pf)))
							.addGap(61)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(btn3)
								.addComponent(btn2))))
					.addContainerGap(72, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(34)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(tf1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1)
						.addComponent(cb1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn1))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 222, GroupLayout.PREFERRED_SIZE)
					.addGap(39)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(tf2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3)
						.addComponent(rb1)
						.addComponent(rb2)
						.addComponent(btn2))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(lblNewLabel_5)
						.addComponent(pf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn3)
						.addComponent(cb2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(72, Short.MAX_VALUE))
		);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//��굥���¼�
				selectRow(e);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5B66\u751F\u7F16\u53F7", "\u5B66\u751F\u59D3\u540D", "\u73ED\u7EA7", "\u6027\u522B", "\u767B\u5F55\u5BC6\u7801"
			}
		));
		scrollPane.setViewportView(table);
		getContentPane().setLayout(groupLayout);
        initClass(); //��ʼ���༶�����б���
        initTable(new Student());//��ʼ��������ʾ����ѧ��
	}
    
	//ɾ������
	protected void deleteAct(ActionEvent e) {
		int row=table.getSelectedRow();
		if(row==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ������");
			return;
		}
		
		//ɾ��ǰ��ѯ��һ��
		if(JOptionPane.showConfirmDialog(this, "��ȷ��Ҫɾ����")!=JOptionPane.OK_OPTION) {
			return;
		}
		
		int id=Integer.parseInt(table.getValueAt(row, 0).toString());
		StudentDao sd=new StudentDao();
		if(sd.delete(id)) {
			JOptionPane.showMessageDialog(this, "ɾ���ɹ�");
		}else
			JOptionPane.showMessageDialog(this, "ɾ��ʧ��");
		
		sd.closeDao();
		initTable(new Student());
		
	}

	//�޸�ѧ����Ϣ
	protected void modifyAct(ActionEvent e) {
		String name=tf2.getText();
		String sex=rb1.isSelected()?rb1.getText():rb2.getText();
		String password=new String(pf.getPassword());
		SClass classname=(SClass)cb2.getSelectedItem();
		
		int row=table.getSelectedRow();
		if(row==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ�����");
			return;
		}
		if(StrUtil.isEmpty(name)) {
			JOptionPane.showMessageDialog(this, "����дѧ������");
			return;
		}
		if(StrUtil.isEmpty(password)) {
			JOptionPane.showMessageDialog(this, "����д����");
			return;
		}
	
		StudentDao sd=new StudentDao();
		Student st=new Student();
		
		st.setId(Integer.parseInt(table.getValueAt(row, 0).toString()));
		st.setName(name);
		st.setSex(sex);
		st.setPassword(password);
		st.setClassId(classname.getId());
		
		if(sd.update(st)) {
			JOptionPane.showMessageDialog(this, "�޸ĳɹ�");
		}else
			JOptionPane.showMessageDialog(this, "�޸�ʧ��");
		sd.closeDao();
        initTable(new Student());
	}

	//���������е��У�ʹ�������ݳ������·���JPanel��
    protected void selectRow(MouseEvent e) {
		int row=table.getSelectedRow();
		
		String name=table.getValueAt(row, 1).toString();
		String sex=table.getValueAt(row, 3).toString();
		String classname=table.getValueAt(row, 2).toString();
		String password=table.getValueAt(row, 4).toString();
				
		tf2.setText(name);
		pf.setText(password);
		if(rb1.getText().equals(sex)) {//ʹ��ѡ��ť��ʾ��Ӧ���Ա�
			rb1.setSelected(true);
		}else {
			rb2.setSelected(true);
		}
		for(int i=0;i<cb2.getItemCount();i++) {//ʹ�����б���ʾ��Ӧ�İ༶����
			SClass sc=(SClass) cb2.getItemAt(i);
			if(classname.equals(sc.getName())) {
				cb2.setSelectedIndex(i);
				break;
			}
		}
	}

	//����ѧ�������Ͱ༶��ѯѧ����Ϣ
	protected void selectTable(ActionEvent e) {
		String name=tf1.getText();
        SClass sc=(SClass) cb1.getSelectedItem();
        Student st=new Student();
        st.setName(name);
        st.setClassId(sc.getId());
		initTable(st);
	}

	//������ѧ����Ϣ��ʾ�������У������ѧ����¼��ֻ�ܲ鿴�Լ���Ϣ��
	protected void initTable(Student student) {
		if("ѧ��".equals(MainJFrm.iden)) {
		  Student st= (Student) MainJFrm.userObject;
		  student.setName(st.getName());//�����ѧ����¼����ѧ��ֻ�ܲ�ѯ�Լ�����Ϣ
		}
		
		StudentDao std=new StudentDao();
		List<Student> list=std.getStudentList(student);
		
		//���ñ������ʾ
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);//��ձ������ݣ������˱����ֶεı��⣩
		
		for(Student s:list) {
			Vector<Object> vec=new Vector<>();//�洢���Ǳ��и��ֶε�ֵ�������ֶ��������Ͳ�ͬ�����Է�����Object
			vec.add(s.getId());
			vec.add(s.getName());
			//vec.add(s.getClassId());//��ʱ��ʾ���ǰ༶id
			vec.add(idChangeName(s.getClassId()));//��ʱ��ʾ���ǰ༶id��Ӧ�İ༶����
			vec.add(s.getSex());
			vec.add(s.getPassword());//�˴��������ݵ�˳�����ͽ����еı������˳�򱣳�һ��
			dtm.addRow(vec);//��Vector�������ӵ������һ����			
		}
		std.closeDao();
	}

	//��ʼ���γ������б���
	private void initClass() {
		ClassDao cd=new ClassDao();
		List<SClass> list=cd.getClassList(new SClass());
		for(SClass sc:list) {
			cb1.addItem(sc);
			cb2.addItem(sc);
		}
		cd.closeDao();
	}
	
	//���༶idת���ɶ�Ӧ�İ༶����
	private String idChangeName(int id){
		ClassDao cd=new ClassDao();
		List<SClass> list=cd.getClassList(new SClass());
		for(SClass s:list) {
			if(s.getId()==id) {
				return s.getName();
			}
		}
		cd.closeDao();
		return "";
	}
	
	
}

