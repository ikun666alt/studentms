package model;

public class Course {
	private int id;
	private String name;
	private int tid;//��ʦ���
	private int maxStuNum;//���ѡ������
	private int selectedNum=0;//��ѡ������������ֱ�Ӹ�ֵ����ѡ�ε��������仯
	private String info;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSelectedNum() {
		return selectedNum;
	}
	public void setSelectedNum(int selectedNum) {
		this.selectedNum = selectedNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getMaxStuNum() {
		return maxStuNum;
	}
	public void setMaxStuNum(int maxStuNum) {
		this.maxStuNum = maxStuNum;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
	public String toString() {
		return this.name;
	}

}
